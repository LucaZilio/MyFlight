package pucrs.myflight.modelo;

public class GerenciadorVoos {

}
